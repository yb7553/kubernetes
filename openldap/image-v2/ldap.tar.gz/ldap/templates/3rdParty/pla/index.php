<?php
// $Header: /cvsroot/lam/lam/templates/3rdParty/pla/index.php,v 1.1 2011/06/26 10:39:01 gruberroland Exp $

/**
 * @package phpLDAPadmin
 */

# You should secure your PLA by making the htdocs/ your docroot.
header('Location: htdocs/index.php');
die();
?>
